package com.bvrith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectIdeaSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
